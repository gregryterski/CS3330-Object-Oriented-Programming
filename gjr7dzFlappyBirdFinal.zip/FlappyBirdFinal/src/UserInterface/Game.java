package UserInterface;

import Classes.BirdMovement;
import Classes.PipeMovement;
import java.awt.Color;
import java.awt.Point;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.edisoncor.gui.panel.PanelImage;
import Sounds.Sound;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

/**
 *
 * @author gjr7dz
 * 
 */

public class Game extends JFrame {

    public static JLabel jBird;
    public static JLabel jLabel1;
    public static JLabel jLabel2;
    public static JLabel jLabel3;
    private final JPanel JPANEL;
    public static JLabel jScore;
    public PanelImage jFloor;
    public static JLabel jDownPipe1;
    public static JLabel jDownPipe2;
    public static JLabel jUpPipe1;
    public static JLabel jUpPipe2;
    public static PanelImage panelImage;
    private BirdMovement birdMovement;
    private PipeMovement pipeMovement;
    private boolean started = false;
    private Score score;
    private final Login LOGIN;
    private JPanel panel1;
    private JPanel panel2;
    public String name;
    public static boolean gameOver = false;
    Point birdPosition;
    public String route = "";
    int speed = 4;
    public ArrayList<String> topNames;
    public ArrayList<Integer> topScores;

    public Game(String nameGiven, ArrayList<String> names, ArrayList<Integer> scores) {
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        JPANEL = new JPanel();
        panelImage = new PanelImage();
        jFloor = new PanelImage();
        jScore = new JLabel();
        jBird = new JLabel();
        jUpPipe1 = new JLabel();
        jDownPipe1 = new JLabel();
        jUpPipe2 = new JLabel();
        jDownPipe2 = new JLabel();
        topNames = names;
        topScores = scores;
        initComponents();
        this.setLocationRelativeTo(null);
        hideObjects(false);
        
        if(nameGiven != null){
            name = nameGiven;
        } else{
            name = "Guest";
        }
        
        LOGIN = new Login(nameGiven);
        showLogin();
        externalEvents();
        this.setTitle("Flappy Bird by Greg Ryterski");
        score = new Score(this);
        birdPosition = jBird.getLocation();
        this.JPANEL.setSize(400, 607);
    }

    @SuppressWarnings("unchecked")
    public void initComponents() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        JPANEL.setBackground(new Color(255, 255, 255));

        panelImage.setIcon(new ImageIcon(getClass().getResource("/Images/Background.png"))); // NOI18N
        panelImage.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                panelImageMousePressed(evt);
            }
        });
        panelImage.setLayout(null);

        jFloor.setIcon(new ImageIcon(getClass().getResource("/Images/Floor.png"))); // NOI18N

        GroupLayout jFloorLayout = new GroupLayout(jFloor);
        jFloor.setLayout(jFloorLayout);
        jFloorLayout.setHorizontalGroup(jFloorLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGap(0, 580, Short.MAX_VALUE)
        );
        jFloorLayout.setVerticalGroup(jFloorLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGap(0, 180, Short.MAX_VALUE)
        );

        panelImage.add(jFloor);
        jFloor.setBounds(-130, 470, 580, 180);

        jScore.setFont(new Font("Tahoma", 1, 40)); // NOI18N
        jScore.setForeground(new Color(255, 255, 255));
        jScore.setHorizontalAlignment(SwingConstants.CENTER);
        jScore.setText("0");
        panelImage.add(jScore);
        jScore.setBounds(0, 10, 400, 49);

        jBird.setIcon(new ImageIcon(getClass().getResource("/Images/Bird.png")));
        
        jBird.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent evt) {
                jFlappyKeyReleased(evt);
            }
        });
        panelImage.add(jBird);
        jBird.setBounds(70, 230, 34, 24);

        jUpPipe1.setIcon(new ImageIcon(getClass().getResource("/Images/Down_pipe.png")));
        panelImage.add(jUpPipe1);
        jUpPipe1.setBounds(70, -120, 52, 320);

        jDownPipe1.setIcon(new ImageIcon(getClass().getResource("/Images/Up_pipe.png")));
        panelImage.add(jDownPipe1);
        jDownPipe1.setBounds(70, 280, 52, 320);

        jUpPipe2.setIcon(new ImageIcon(getClass().getResource("/Images/Down_pipe.png")));
        panelImage.add(jUpPipe2);
        jUpPipe2.setBounds(290, -120, 52, 320);

        jDownPipe2.setIcon(new ImageIcon(getClass().getResource("/Images/Up_pipe.png")));
        panelImage.add(jDownPipe2);
        jDownPipe2.setBounds(290, 280, 52, 320);

        GroupLayout jPanel1Layout = new GroupLayout(JPANEL);
        JPANEL.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(panelImage, GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
                        .addGap(0, 0, 0))
        );
        jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(panelImage, GroupLayout.PREFERRED_SIZE, 600, GroupLayout.PREFERRED_SIZE)
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(JPANEL, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(JPANEL, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        );
        pack();
    }

    private void jFlappyKeyReleased(KeyEvent evt) {
        if (started) {
            if (evt.getExtendedKeyCode() == 32) {
                this.birdMovement.setSpeed(increaseSpeed());
                this.birdMovement.setSkip(true);
                jBird.requestFocus(true);
                Sound.skip();
            }
            startShockPipes();
        }
    }

    private void panelImageMousePressed(MouseEvent evt) {
        if (started) {
            this.birdMovement.setSpeed(increaseSpeed());
            this.birdMovement.setSkip(true);
            jBird.requestFocus(true);
            Sound.skip();
        }
    }

    private int increaseSpeed() {
        int points = Integer.parseInt(jScore.getText());
        if (points == 150 || points == 300) {
            speed = speed - 1;
        }
        return speed;
    }

    private void externalEvents() {
        LOGIN.jButton.addActionListener((ActionEvent evt) -> {
            jButtonActionPerformed(evt);
        });
    }

    private void jButtonActionPerformed(ActionEvent evt) {
        this.panel1.setVisible(false);
        start();
        hideObjects(true);
    }

    public void start() {
        pipeMovement = new PipeMovement();
        birdMovement = new BirdMovement(this);
        pipeMovement.start(); //Both of these extend thread so you don't call the run() you call start()
        birdMovement.start();
        started = true;
        jBird.requestFocus();
        this.setTitle("Flappy Bird by Greg Ryterski");
    }

    public void startShockPipes() {
        Point birdLocation = jBird.getLocation();
        Point pipe1Location = jUpPipe1.getLocation();
        Point pipe2Location = jUpPipe2.getLocation();
        Point pipe3Location = jDownPipe1.getLocation();
        Point pipe4Location = jDownPipe2.getLocation();
        if (birdLocation.x > (pipe1Location.x - 32) && birdLocation.x < ((pipe1Location.x - 32) + 82) && birdLocation.y < (pipe1Location.y + 318)) {
            Sound.shock();
            this.pipeMovement.stop();
            this.birdMovement.setSkip(false);
            started = false;
            Sound.drop();
        } else if (birdLocation.x > (pipe2Location.x - 32) && birdLocation.x < ((pipe2Location.x - 32) + 82) && birdLocation.y < (pipe2Location.y + 318)) {
            Sound.shock();
            this.pipeMovement.stop();
            this.birdMovement.setSkip(false);
            started = false;
            Sound.drop();
        } else if (birdLocation.x > (pipe3Location.x - 32) && birdLocation.x < ((pipe3Location.x - 32) + 82) && birdLocation.y > (pipe3Location.y - 22)) {
            Sound.shock();
            this.pipeMovement.stop();
            this.birdMovement.setSkip(false);
            started = false;
            Sound.drop();
        } else if (birdLocation.x > (pipe4Location.x - 32) && birdLocation.x < ((pipe4Location.x - 32) + 82) && birdLocation.y > (pipe4Location.y - 22)) {
            Sound.shock();
            this.pipeMovement.stop();
            this.birdMovement.setSkip(false);
            started = false;
            Sound.drop();
        }
    }

    private void hideObjects(boolean action) {
        jBird.setVisible(action);
        jDownPipe1.setVisible(action);
        jDownPipe2.setVisible(action);
        jUpPipe1.setVisible(action);
        jUpPipe2.setVisible(action);
        jScore.setVisible(action);
    }

    public synchronized void startShock() {
        int y = jBird.getLocation().y;
        if (y == 448) {
            if (Sound.fallShock) {
                Sound.shock();
            }
            try {
                Thread hilo = new Thread() {
                    @Override
                    public void run() {
                        pipeMovement.stop();
                        BirdMovement.threadDisabled = true;
                        stop();
                    }
                };
                hilo.start();
            } catch (Exception e) {
            }
            showScore();
        }
    }

    public void showScore() {
        Sound.fallDrop = true;
        Sound.fallShock = true;
        hideObjects(false);
        panel2 = new JPanel();
        panel2.setBounds(0, 0, this.getWidth(), 550);
        panel2.add(score);
        score.setBounds(0, 0, panel2.getWidth(), panel2.getHeight());
        panelImage.add(panel2);
        panel2.setBackground(new Color(255, 255, 153));
        score.setVisible(true);
        score.show();
        panel2.setVisible(true);
    }

    public void newStart() {
        jBird.setLocation(birdPosition);
        jScore.setText("0");
        this.panel2.setVisible(false);
        start();
        hideObjects(true);
        score = new Score(this);
    }

    private void showLogin() {
        panel1 = new JPanel();
        panel1.setBounds(10, 200, 380, 140);
        panel1.add(LOGIN);
        LOGIN.setBounds(0, 0, panel1.getWidth(), panel1.getHeight());
        panelImage.add(panel1);
        panel1.setBackground(new Color(255, 255, 153));
        LOGIN.setVisible(true);
        panel1.setVisible(true);
    }

}
