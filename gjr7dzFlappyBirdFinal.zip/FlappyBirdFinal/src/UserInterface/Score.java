package UserInterface;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.LayoutStyle;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author gjr7dz
 * 
 */

public class Score extends JPanel {

    Game parent;
    boolean connect;
    int count = 1;
    private JButton jButton1;
    private JButton jButton2;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3; 
    private JLabel jLabel4; //4-9 Leaderboard Labels
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    private JLabel jLabel8;
    private JLabel jLabel9;
    private JLabel jLabel10;
    private JPanel jPanel1;
    private JPanel jPanel2;

    public Score(Game parent) {
        initComponents();
        this.parent = parent;
    }

    @Override
    public void show() {
        this.jLabel3.setText(parent.name + "                                " + Game.jScore.getText()); //8 Tabs
        if(parent.topNames.size() > 0 || parent.topScores.size() > 0){
            this.jLabel5.setText(parent.topNames.get(0) + "                               " + parent.topScores.get(0));
        }
        if(parent.topNames.size() > 1 || parent.topScores.size() > 1){
            this.jLabel6.setText(parent.topNames.get(1) + "                               " + parent.topScores.get(1));
        }
        if(parent.topNames.size() > 2 || parent.topScores.size() > 2){
            this.jLabel7.setText(parent.topNames.get(2) + "                               " + parent.topScores.get(2));
        }
        if(parent.topNames.size() > 3 || parent.topScores.size() > 3){
            this.jLabel8.setText(parent.topNames.get(3) + "                               " + parent.topScores.get(3));
        }
        if(parent.topNames.size() > 4 || parent.topScores.size() > 4){
            this.jLabel9.setText(parent.topNames.get(4) + "                               " + parent.topScores.get(4));
        }
        writeToFile(Game.jScore.getText());
        
        this.parent.jFloor.setVisible(true);
    }

    public void initComponents() {
        jPanel1 = new JPanel();
        jPanel2 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        jLabel6 = new JLabel();
        jLabel7 = new JLabel();
        jLabel8 = new JLabel();
        jLabel9 = new JLabel();
        jLabel10 = new JLabel();
        jButton1 = new JButton();
        jButton2 = new JButton();

        jPanel1.setBackground(new Color(255, 255, 153));

        jPanel2.setBackground(new Color(255, 255, 153));
        jPanel2.setBorder(BorderFactory.createTitledBorder(new LineBorder(new Color(0, 0, 0), 1, true), "Score", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Tahoma", 1, 12), new Color(0, 0, 0)));

        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setIcon(new ImageIcon(getClass().getResource("/Images/Game_Over.png")));
        
        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel10.setHorizontalAlignment(SwingConstants.LEFT);
        jLabel10.setText("User:                         Score:"); //7 Tabs
        
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel4.setHorizontalAlignment(SwingConstants.LEFT);
        jLabel4.setText("Top 5 LeaderBoard:");

        jLabel3.setFont(new Font("Tahoma", 1, 18));
        jLabel3.setForeground(new Color(255, 102, 0));
        jLabel3.setHorizontalAlignment(SwingConstants.LEFT);
        
        jLabel5.setFont(new Font("Tahoma", 1, 18));
        jLabel5.setForeground(new Color(255, 102, 0));
        jLabel5.setHorizontalAlignment(SwingConstants.LEFT);
        
        jLabel6.setFont(new Font("Tahoma", 1, 18));
        jLabel6.setForeground(new Color(255, 102, 0));
        jLabel6.setHorizontalAlignment(SwingConstants.LEFT);
        
        jLabel7.setFont(new Font("Tahoma", 1, 18));
        jLabel7.setForeground(new Color(255, 102, 0));
        jLabel7.setHorizontalAlignment(SwingConstants.LEFT);
        
        jLabel8.setFont(new Font("Tahoma", 1, 18));
        jLabel8.setForeground(new Color(255, 102, 0));
        jLabel8.setHorizontalAlignment(SwingConstants.LEFT);
        
        jLabel9.setFont(new Font("Tahoma", 1, 18));
        jLabel9.setForeground(new Color(255, 102, 0));
        jLabel9.setHorizontalAlignment(SwingConstants.LEFT);

        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setText(" ");

        GroupLayout jPanel3Layout = new GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel10, GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)
                                .addComponent(jLabel4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel9, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE) 
                        .addComponent(jLabel10)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addContainerGap())
        );

        jButton1.setFont(new Font("Tahoma", 1, 12));
        jButton1.setForeground(new Color(255, 100, 0));
        jButton1.setText("Click to Play Again");
        jButton1.addActionListener((ActionEvent evt) -> {
            jButton1ActionPerformed(evt);
        });
        
        jButton2.setFont(new Font("Tahoma", 1, 12));
        jButton2.setForeground(new Color(255, 100, 0));
        jButton2.setText("Exit Game");
        jButton2.addActionListener((ActionEvent evt) -> {
            jButton2ActionPerformed(evt);
        });

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.CENTER)
                                .addComponent(jButton1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(10, 10, Short.MAX_VALUE)
                        .addComponent(jButton2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
        );

        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(0, 0, 0))
        );
    }

    private void jButton1ActionPerformed(ActionEvent evt) {
        this.parent.newStart();
    }
    
    private void jButton2ActionPerformed(ActionEvent evt) {
        System.exit(0);
    }
    
    private void writeToFile(String score){
        try(FileWriter fw = new FileWriter("names.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw)) {
            out.write(this.parent.name);
            out.write(" ");
            out.write(score);
            out.write("\n");
            out.close();
        } catch(IOException e){
            System.out.println("Error: " + e.toString());
        }
    }
}
