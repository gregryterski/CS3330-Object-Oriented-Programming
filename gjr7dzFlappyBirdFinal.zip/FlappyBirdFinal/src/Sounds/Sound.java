package Sounds;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

/**
 *
 * @author gjr7dz
 * 
 */

public class Sound {

    private static File file;
    private static String route;
    public static boolean fallShock = true;
    public static boolean fallDrop = true;

    public static void skip() {
        file = new File(".");
        route = file.getAbsolutePath();
        Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1);
                    FileInputStream fis;
                    Player player;
                    try{
                        fis = new FileInputStream(route + "/src/Sounds/Skip.mp3");
                    }catch (FileNotFoundException e){
                        fis = new FileInputStream(route + "/accessories/Skip.mp3");
                    }
                    BufferedInputStream bis = new BufferedInputStream(fis);
                    player = new Player(bis);
                    player.play();
                    stop();
                } catch (InterruptedException | JavaLayerException | FileNotFoundException e) {
                    System.out.println(" error " + e);
                }

            }
        };
        thread.start();
    }

    public static void drop() {
        if (fallDrop){
            fallDrop = false;
            file = new File(".");
            route = file.getAbsolutePath();
            Thread thread = new Thread() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(500);
                        FileInputStream inputFile;
                        Player player;
                        try{
                            inputFile = new FileInputStream(route + "/src/sounds/Drop.mp3");
                        }catch (FileNotFoundException e){
                            inputFile = new FileInputStream(route + "/accessories/Drop.mp3");
                        }
                        BufferedInputStream inputBuffered = new BufferedInputStream(inputFile);
                        player = new Player(inputBuffered);
                        player.play();
                        stop();
                    } catch (InterruptedException | JavaLayerException | FileNotFoundException e) {
                    }
                }
            };
            thread.start();
        }
    }

    public static void shock() {
        if (fallShock){
            fallShock = false;
            file = new File(".");
            route = file.getAbsolutePath();
            Thread thread = new Thread() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(1);
                        FileInputStream inputFile;
                        Player player;
                        try{
                            inputFile = new FileInputStream(route + "/src/sounds/Shock.mp3");
                        }catch(FileNotFoundException e){
                            inputFile = new FileInputStream(route + "/accessories/Shock.mp3");
                        }
                        BufferedInputStream inputBuffered = new BufferedInputStream(inputFile);
                        player = new Player(inputBuffered);
                        player.play();
                        stop();
                    } catch (InterruptedException | JavaLayerException | FileNotFoundException e) {
                    }
                }
            };
            thread.start();
        }
    }

    public static void points() {
        file = new File(".");
        route = file.getAbsolutePath();
        Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1);
                    FileInputStream inputFile;
                    Player player;
                    try{
                        inputFile = new FileInputStream(route + "/src/sounds/Points.mp3");
                    } catch(FileNotFoundException e){
                        inputFile = new FileInputStream(route + "/accessories/Points.mp3");
                    }
                    BufferedInputStream inputBuffered = new BufferedInputStream(inputFile);
                    player = new Player(inputBuffered);
                    player.play();
                    stop();
                } catch (InterruptedException | JavaLayerException | FileNotFoundException e) {
                }
            }
        };
        thread.start();
    }

}
