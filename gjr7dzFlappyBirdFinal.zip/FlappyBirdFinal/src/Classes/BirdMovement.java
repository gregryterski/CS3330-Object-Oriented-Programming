package Classes;

import UserInterface.Game;

/**
 *
 * @author gjr7dz
 * 
 */

public class BirdMovement extends Thread {

    private int speed;
    private boolean skip;
    private boolean jumpDisabled1 = false;
    private boolean jumpDisabled2 = true;
    private boolean jumping = false;
    private final Game PARENT;
    public static boolean threadDisabled;

    public BirdMovement(Game parent) {
        this.speed = 10;
        this.PARENT = parent;
    }

    @Override
    public void run() {
        int counter = 1;
        threadDisabled = false;
        while (true) {
            if (threadDisabled) {
                break;
            }
            int x = Game.jBird.getLocation().x;
            if (!isSkip()) {
                int y = Game.jBird.getLocation().y;
                try {
                    Thread.sleep(getSpeed());
                    Game.jBird.setLocation(x, (y + 1));
                    if (speed > 3) {
                        if (counter % 15 == 0) {
                            speed = speed - 1;
                        }
                        counter = counter + 1;
                    }
                    PARENT.startShockPipes();
                } catch (InterruptedException e) {
                    System.out.println("Error Occured: " + e);
                }
            } else {
                if (!jumping) {
                    setJumpDisabled1(false);
                    setJumpDisabled2(true);
                    jumping = true;
                    jump1();
                } else {
                    setJumpDisabled1(true);
                    setJumpDisabled2(false);
                    jumping = false;
                    jump2();
                }
            }
            this.PARENT.startShock();
        }
    }

    private void jump1() {
        int jumpTime = 1;
        while (true) {
            int y = Game.jBird.getLocation().y;
            int x = Game.jBird.getLocation().x;
            try {
                Thread.sleep(getSpeed());
                if (!isJumpDisabled1()) {
                    jumpTime = jumpTime + 1;
                    if (jumpTime <= 60) {
                        Game.jBird.setLocation(x, (y - 1));
                        if (jumpTime % 20 == 0) {
                            speed = speed - 1;
                        }
                    } else if (jumpTime >= 70) {
                        setSkip(false);
                        setSpeed(7);
                        break;
                    }
                    PARENT.startShockPipes();
                } else {
                    break;
                }
            } catch (InterruptedException e) {
                System.out.println("Error Occured: " + e);
            }
        }
    }

    private void jump2() {
        int jumpTime = 1;
        while (true) {
            int y = Game.jBird.getLocation().y;
            int x = Game.jBird.getLocation().x;
            try {
                Thread.sleep(getSpeed());
                if (!isJumpDisabled2()) {
                    jumpTime = jumpTime + 1;
                    if (jumpTime <= 60) {
                        Game.jBird.setLocation(x, (y - 1));
                        if (jumpTime % 20 == 0) {
                            speed = speed - 1;
                        }
                    } else if (jumpTime >= 70) {
                        setSkip(false);
                        setSpeed(7);
                        break;
                    }
                    PARENT.startShockPipes();
                } else {
                    break;
                }
            } catch (InterruptedException e) {
                System.out.println("Error Occured: " + e);
            }
        }
    }

    public boolean isJumpDisabled1() {
        return jumpDisabled1;
    }

    public void setJumpDisabled1(boolean jumpDisabled1) {
        this.jumpDisabled1 = jumpDisabled1;
    }

    public boolean isJumpDisabled2() {
        return jumpDisabled2;
    }

    public void setJumpDisabled2(boolean jumpDisabled2) {
        this.jumpDisabled2 = jumpDisabled2;
    }

    public boolean isSkip() {
        return skip;
    }

    public void setSkip(boolean skip) {
        this.skip = skip;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public boolean isThreadDisabled() {
        return threadDisabled;
    }

}
