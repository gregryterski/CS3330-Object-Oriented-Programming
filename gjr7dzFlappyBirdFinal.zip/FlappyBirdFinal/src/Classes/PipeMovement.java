package Classes;

import UserInterface.Game;
import Sounds.Sound;

/**
 *
 * @author gjr7dz
 * 
 */

public class PipeMovement extends Thread {

    static int speed;
    private static int points;

    public PipeMovement() {
        speed = 7;
        points = 0;
        hidePipes();
    }

    private static synchronized void addPoints() {
        int pipe1 = Game.jUpPipe1.getLocation().x;
        int pipe2 = Game.jUpPipe2.getLocation().x;
        if (pipe1 == 90) {
            Sound.points();
            points = points + 1;
            Game.jScore.setText(points + "");
            if (points == 30 || points == 50 || points == 130 || points == 160 || points == 200 || points == 300) {
                speed = speed - 1;
            }
        } else if (pipe2 == 90) {
            Sound.points();
            points = points + 1;
            Game.jScore.setText(points + "");
            if (points == 30 || points == 50 || points == 130 || points == 160 || points == 200 || points == 300) {
                speed = speed - 1;
            }
        }
    }

    @Override
    public void run() {
        int position1 = getRandomPosition();
        int position2 = getRandomPosition();
        int x1 = Game.jUpPipe1.getLocation().x;
        int x2 = Game.jUpPipe2.getLocation().x;
        while (true) {
            try {
                Thread.sleep(getSpeed());
                x1--;
                x2--;
                Game.jUpPipe1.setLocation(x1, position1);
                Game.jDownPipe1.setLocation(x1, (position1 + 425));
                Game.jUpPipe2.setLocation(x2, position2);
                Game.jDownPipe2.setLocation(x2, (position2 + 425));
                if (x1 <= -51) {
                    position1 = getRandomPosition();
                    x1 = 425;
                }
                if (x2 <= -51) {
                    position2 = getRandomPosition();
                    x2 = 425;
                }
                addPoints();
            } catch (InterruptedException ex) {
                System.out.println("Problems moving pipes: " + ex);
            }
        }
    }

    private void hidePipes() {
        Game.jUpPipe1.setLocation(460, 500);
        Game.jDownPipe1.setLocation(460, 1000);
        Game.jUpPipe2.setLocation(700, 500);
        Game.jDownPipe2.setLocation(700, 1000);
    }

    public int getSpeed() {
        return speed;
    }

    private int getRandomPosition() {
        int randNum = (int) (Math.random() * (0 - (-200)) + (-200));
        return randNum;
    }

}
