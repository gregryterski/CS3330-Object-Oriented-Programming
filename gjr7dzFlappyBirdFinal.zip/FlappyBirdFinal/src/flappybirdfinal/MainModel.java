/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybirdfinal;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import javafx.scene.control.TextInputDialog;

/**
 *
 * @author gjr7dz
 */
public class MainModel extends AbstractModel {
    public ArrayList<String> names;
    public ArrayList<Integer> scores;

    private ArrayList<String> namesHolder;
    private ArrayList<Integer> scoresHolder;
    
    public MainModel(){
    }
    
    public void loadLeaderBoard() throws FileNotFoundException, IOException {
        File file = new File("names.txt");
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String c = "";
        namesHolder = new ArrayList<>();
        scoresHolder = new ArrayList<>();
        while((c = br.readLine()) != null){
            if(!c.isEmpty()){
                String[] splitLine = c.split(" ");
                namesHolder.add(splitLine[0]);
                scoresHolder.add(Integer.parseInt(splitLine[1]));
            }
        }
        topFivePlayers();
        br.close();
    }
    
    private int getHighestValueLocation(ArrayList<Integer> num){
        int maxLocation = 0;
        int holder = 0;
        for(int i = 0; i < num.size(); i++){
            if(num.get(i) > holder){
                maxLocation = i;
                holder = num.get(i);
            }
        }
        return maxLocation;
    }
    
    private void topFivePlayers(){
        int location = 0;
        int size = scoresHolder.size();
        names = new ArrayList<>();
        scores = new ArrayList<>();
        for(int i = 0; i < size; i++){
            location = getHighestValueLocation(scoresHolder);
            if((names.size() != 5) && (scores.size() != 5)){
                names.add(namesHolder.get(location));
                scores.add(scoresHolder.get(location));
            }
            namesHolder.remove(location);
            scoresHolder.remove(location);
        }
    }
    
    public void createNewUser() { 
        TextInputDialog timePrompt = new TextInputDialog();
        timePrompt.setTitle("Creating a new user");
        timePrompt.setHeaderText("Set the username:");
        timePrompt.setContentText("Please enter a username no spaces:");
        Optional<String> result = timePrompt.showAndWait();
        if(!result.isPresent()){
            return;
        } else{
            String name = result.get();
            updateUser(name);
        }
    }
    
    public void updateUser(String userName){
        firePropertyChange("UserName", null, userName);
    }
}
