/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybirdfinal;

import javafx.stage.Stage;

/**
 *
 * @author gjr7dz
 */
public interface SwitchScene {
    public void start(Stage stage);
}
