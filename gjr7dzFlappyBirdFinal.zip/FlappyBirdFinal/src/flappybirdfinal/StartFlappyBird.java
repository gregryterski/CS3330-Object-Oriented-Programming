/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybirdfinal;

import UserInterface.Game;
import java.util.ArrayList;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author gjr7dz
 */
public class StartFlappyBird {
    
    public StartFlappyBird(){
    }
    
    public void start(String name, ArrayList<String> topNames, ArrayList<Integer> topScores){
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Name".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            new Game(name, topNames, topScores).setVisible(true);
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            System.out.println("Error while starting the game: " + ex.toString());
        }
    }
}
