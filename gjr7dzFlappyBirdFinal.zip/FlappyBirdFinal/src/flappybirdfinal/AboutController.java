/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybirdfinal;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author gjr7dz
 */
public class AboutController implements Initializable, SwitchScene {
    
    private Stage stage; 
    public Scene mainScene; 
    public MainController mainController; 
    
    @FXML
    private Button backButton;
    @FXML
    private Rectangle rectangle;
    @FXML
    private Label aboutText;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }    
    
    @Override
    public void start(Stage stage){
        this.stage = stage; 
    }

    @FXML
    private void returnToGame(ActionEvent event) {
        stage.setScene(mainScene); 
    }

}
