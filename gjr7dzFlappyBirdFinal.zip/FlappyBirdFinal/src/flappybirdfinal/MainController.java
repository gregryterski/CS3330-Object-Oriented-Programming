/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybirdfinal;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author gjr7dz
 */
public class MainController implements Initializable, SwitchScene, PropertyChangeListener {

    private Stage stage;
    private Scene mainScene;
    private Scene aboutScene;
    private AboutController aboutController;
    private String userName;
    private MainModel model;
            
    @FXML
    private AnchorPane pane;
    @FXML
    private Button aboutButton;
    @FXML
    private Button newUserBtn;
    @FXML
    private Button playGameBtn;
    @FXML
    private ImageView background;
    @FXML
    private ImageView floor;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        model = new MainModel();
        model.addPropertyChangeListener(this);
    }    
    
    @Override
    public void start(Stage stage){
        this.stage = stage; 
        mainScene = stage.getScene();  
    }

    @FXML
    private void switchToAbout(ActionEvent event) {
        
        try {
            if(aboutScene == null){              
                FXMLLoader loader = new FXMLLoader(getClass().getResource("AboutView.fxml"));
                Parent page2Root = loader.load(); 
                aboutController = loader.getController(); 
                aboutController.mainScene = mainScene; 
                aboutController.mainController = this; 
                aboutScene = new Scene(page2Root); 
            }
        } catch (IOException ex){
            System.out.println("Error when switching to about: " + ex.toString());
        }
        
        stage.setScene(aboutScene); 
        aboutController.start(stage);
    }

    @FXML
    private void createNewUser(ActionEvent event) {
        model.createNewUser();
    }


    @FXML
    private void playGame(ActionEvent event) throws IOException {
        newUserBtn.setVisible(false);
        playGameBtn.setVisible(false);
        aboutButton.setVisible(false);
        stage.hide();
        model.loadLeaderBoard();
        StartFlappyBird obj = new StartFlappyBird();
        obj.start(userName, model.names, model.scores);
    }
    
    @Override
    public void propertyChange(PropertyChangeEvent evt){
        if(evt.getPropertyName().equals("UserName")){
            userName = evt.getNewValue().toString();
        } else{
            System.out.println("Something went wrong");
        }
    }
}
