/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gjr7dzgpacalculatorf20;

import java.util.Optional;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author gregryterski
 */
public class Gjr7dzGPACalculatorF20 extends Application {
    
    public String title = "GPA Caluclator";
    public int width = 400;
    public int height = 400;
    public String fontStyle = "Comic Sans MS";
    public double finalVal = 0;
    public double desiredGrade;
    public int numOfScores;
    public String grade;
    public double scoreOnee;
    public double scoreTwoo;
    public double scoreThreee;
    public double scoreFourr;
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle(title);
        
        GridPane root = new GridPane();
        root.setAlignment(Pos.BASELINE_CENTER);
        root.setHgap(8);
        root.setVgap(8);
        root.setPadding(new Insets(10, 0 , 10, 0));
        
        
        Label course1 = new Label("Course 1: ");
        course1.setFont(Font.font(fontStyle, FontWeight.NORMAL, 10));
        root.add(course1, 0, 0);
        
        TextField scoreOne = new TextField();
        scoreOne.setPrefWidth(300);
        root.add(scoreOne, 1, 0);
        
        Label course2 = new Label("Course 2: ");
        course2.setFont(Font.font(fontStyle, FontWeight.NORMAL, 10));
        root.add(course2, 0, 1);
        
        TextField scoreTwo = new TextField();
        scoreTwo.setPrefWidth(300);
        root.add(scoreTwo, 1, 1);
        
        Label course3 = new Label("Course 3: ");
        course3.setFont(Font.font(fontStyle, FontWeight.NORMAL, 10));
        root.add(course3, 0, 2);
        
        TextField scoreThree = new TextField();
        scoreThree.setPrefWidth(300);
        root.add(scoreThree, 1, 2);
        
        Label course4 = new Label("Course 4: ");
        course4.setFont(Font.font(fontStyle, FontWeight.NORMAL, 10));
        root.add(course4, 0, 3);
        
        TextField scoreFour = new TextField();
        scoreFour.setPrefWidth(300);
        root.add(scoreFour, 1, 3); 
        
        Label finalS = new Label("Final GPA: ");
        finalS.setFont(Font.font(fontStyle, FontWeight.NORMAL, 10));
        finalS.setWrapText(true);
        root.add(finalS, 0, 4);
        
        TextArea finalScore = new TextArea();
        finalScore.setEditable(false);
        finalScore.setPrefWidth(300);
        finalScore.setWrapText(true);
        root.add(finalScore, 1, 4);
        
        VBox vboxForButton = new VBox(10);
        vboxForButton.setAlignment(Pos.BOTTOM_RIGHT);
        vboxForButton.setSpacing(15);
        vboxForButton.setPadding(new Insets(10, 0, 10, 0));
        root.add(vboxForButton, 0, 5, 2, 1);
        
        TextInputDialog gradeDesired = new TextInputDialog(); //Start of geeksforgeeks.org/javafx-textinputdialog/
        gradeDesired.setHeaderText("Calculate Desired GPA");
        gradeDesired.setTitle("GPA");
        gradeDesired.setContentText("Please enter your desired GPA (0-4): ");
       
        Button btn1 = new Button("EmulateGPA");
        btn1.setMaxWidth(Double.MAX_VALUE);
        vboxForButton.getChildren().add(btn1);
        
        btn1.setOnAction((ActionEvent event) -> {
            Optional<String> result = gradeDesired.showAndWait(); //Start & End of code.makery.ch/blog/javafx-dialogs-official/
            if(result.isPresent()){
            int resultInt = Integer.parseInt(result.get());
            
            switch (resultInt) {
                case 4:
                    scoreOne.setText("100");
                    scoreTwo.setText("100");
                    scoreThree.setText("100");
                    scoreFour.setText("100");
                    break;
                case 3:
                    scoreOne.setText("83");
                    scoreTwo.setText("83");
                    scoreThree.setText("83");
                    scoreFour.setText("83");
                    break;
                case 2:
                    scoreOne.setText("73");
                    scoreTwo.setText("73");
                    scoreThree.setText("73");
                    scoreFour.setText("73");
                    break;
                case 1:
                    scoreOne.setText("63");
                    scoreTwo.setText("63");
                    scoreThree.setText("63");
                    scoreFour.setText("63");
                    break;
                case 0:
                    scoreOne.setText("0");
                    scoreTwo.setText("0");
                    scoreThree.setText("0");
                    scoreFour.setText("0");
                    break;
                default:
                    Alert error = new Alert(AlertType.ERROR);
                    error.setTitle("Error");
                    error.setHeaderText("Error");
                    error.setContentText("Inserts integer from 0 to 4");
                    error.showAndWait();
                    break;
            }
            }
        });
        
        Button btn2 = new Button("Calculate GPA");
        btn2.setMaxWidth(Double.MAX_VALUE);
        vboxForButton.getChildren().add(btn2);
        btn2.setOnAction((ActionEvent event) -> {
            scoreOnee = 0.0;
            scoreTwoo = 0.0;
            scoreThreee = 0.0;
            scoreFourr = 0.0;
            grade = "";
            finalVal = 0.0;
            numOfScores = 0;
            
            if(scoreOne.getText() == null || scoreOne.getText().trim().isEmpty()){ //Start & end https://stackoverflow.com/questions/32866937/how-to-check-if-textfield-is-empty
            } else{
                scoreOnee = Double.parseDouble(scoreOne.getText()); //Start & end https://www.geeksforgeeks.org/convert-string-to-double-in-java/
                numOfScores++;
            }
            
            if(scoreTwo.getText() == null || scoreTwo.getText().trim().isEmpty()){
            } else{
                scoreTwoo = Double.parseDouble(scoreTwo.getText());
                numOfScores++;
            }
            
            if(scoreThree.getText() == null || scoreThree.getText().trim().isEmpty()){
            } else{
                scoreThreee = Double.parseDouble(scoreThree.getText());
                numOfScores++;
            }
            
            if(scoreFour.getText() == null || scoreFour.getText().trim().isEmpty()){
            } else{
                scoreFourr = Double.parseDouble(scoreFour.getText());
                numOfScores++;
            }
           
            finalVal = ((scoreOnee+scoreTwoo+scoreThreee+scoreFourr)/numOfScores)/100;
            
            if(finalVal >= 0.975){
                grade = "A+";
            }
            else if(finalVal >= 0.93 && finalVal < 0.975) {
                grade = "A";
            }
            else if(finalVal >= 0.895 && finalVal < 0.93){
                grade = "A-";
            }
            else if(finalVal >= 0.875 && finalVal < 0.895){
                grade = "B+";
            }
            else if(finalVal >= 0.825 && finalVal < 0.875){
                grade = "B";
            }
            else if(finalVal >= 0.795 && finalVal < 0.825){
                grade = "B-";
            }
            else if(finalVal >= 0.775 && finalVal < 0.795){
                grade = "C+";
            }
            else if(finalVal >= 0.725 && finalVal < 0.775){
                grade = "C";
            }
            else if(finalVal >= 0.695 && finalVal < 0.725){
                grade = "C-";
            }
            else if(finalVal >= 0.675 && finalVal < 0.695){
                grade = "D+";
            }
            else if(finalVal >= 0.625 && finalVal < 0.675){
                grade = "D";
            }
            else if(finalVal >= 0.595 && finalVal < 0.625){
                grade = "D-";
            }
            else if(finalVal < 0.595){
                grade = "F";
            }
            
            finalScore.setText("My final score should be \n((" + scoreOnee + "+" + scoreTwoo + "+" +
                    scoreThreee + "+" + scoreFourr + ")/" + numOfScores + ")/100 = " + grade);
        });
        
        Button btn3 = new Button("Clear All");
        btn3.setMaxWidth(Double.MAX_VALUE);
        vboxForButton.getChildren().add(btn3);
        btn3.setOnAction((ActionEvent event) -> {
            scoreOnee = 0.0;
            scoreTwoo = 0.0;
            scoreThreee = 0.0;
            scoreFourr = 0.0;
            grade = "";
            finalVal = 0.0;
            numOfScores = 0;
            scoreOne.setText("");
            scoreTwo.setText("");
            scoreThree.setText("");
            scoreFour.setText("");
            finalScore.setText("");
        });
        
        Button btn4 = new Button("ALERT");
        btn4.setMaxWidth(Double.MAX_VALUE);
        vboxForButton.getChildren().add(btn4);
        btn4.setOnAction((ActionEvent event)-> {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Alert");
            alert.setHeaderText("Message");
            alert.setContentText("My final score should be \n((" + scoreOnee + "+" + scoreTwoo + "+" +
                    scoreThreee + "+" + scoreFourr + ")/" + numOfScores + ")/100 = " + grade);
            
            alert.showAndWait();
        });
        
        Scene scene = new Scene(root, width, height);
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
