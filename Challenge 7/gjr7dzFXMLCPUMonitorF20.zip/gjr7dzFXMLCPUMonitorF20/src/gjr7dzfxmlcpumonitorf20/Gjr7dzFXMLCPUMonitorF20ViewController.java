/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gjr7dzfxmlcpumonitorf20;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.util.Duration;

/**
 *
 * @author gregryterski
 */
public class Gjr7dzFXMLCPUMonitorF20ViewController implements Initializable {
    
    private int count = 0;
    private int cpuData = 0;
    private int recordData = 0;
    private boolean firstRun = true;
    private static double cpu = 0;
    private static long mem = 0;
    private Timeline timeline;
    private XYChart.Series series;
    private XYChart.Series recordSeries;
    
    @FXML
    public Button memButton;
    @FXML
    public Label memLabel;
    @FXML
    private NumberAxis cpuY;
    @FXML
    private NumberAxis cpuX;
    @FXML
    private NumberAxis recY;
    @FXML
    private NumberAxis recX;
    @FXML
    private GridPane root;
    @FXML
    private AreaChart<?, ?> cpuLoad;
    @FXML
    private LineChart recordedUsage;
    @FXML
    private Label cpuLabel;
    @FXML
    private Label recordingTime;
    @FXML
    private HBox controlButtons;
    @FXML
    private Button startBtn;
    @FXML
    private Button resetBtn;
    @FXML
    private ImageView guageImage;
    @FXML
    private ImageView handImage;
    
    
    @FXML
    public void startButton(ActionEvent event) {
        if(isRunning()){
                stop();
                startBtn.setStyle("-fx-background-color:#7CFC00");
                startBtn.setText("Start");
                resetBtn.setText("Reset");
            }
            else {
                startBtn.setStyle("-fx-background-color:FF0000");
                startBtn.setText("Stop");
                resetBtn.setText("Record");
                updateDigital();
                start();
                firstRun = false;
            }
    }
    
    @FXML
    public void resetButton(ActionEvent event) {
        if(isRunning()){
            if(firstRun == false){
            recordTitle();
            recordCPUChart();
            }
        }
        else {
            if(firstRun == false) reset();
        }
    }
    
    @FXML
    public void sizeButton(ActionEvent event) {
        if(firstRun == false) updateMemSize();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        series = new XYChart.Series();
        cpuLoad.getData().add(series);
        recordSeries = new XYChart.Series();
        recordedUsage.getData().add(recordSeries);
        
        
        handImage.setRotate(195);
        timeline = new Timeline(new KeyFrame(Duration.millis(1000), (ActionEvent) -> {
            cpu = this.getCPUUsage();
            mem = this.getMEMUsage(); 
            
            if(!Double.isNaN(cpu)){
                updateDigital();
                update();
                cpuLoadChart();
            }
        }));
        
        timeline.setCycleCount(Animation.INDEFINITE);
    }
    
    public double getCPUUsage() {
        OperatingSystemMXBean operatingSystemMXBean = ManagementFactory.getOperatingSystemMXBean();
        double value = 0;
        
        for(Method method : operatingSystemMXBean.getClass().getDeclaredMethods()) {
            method.setAccessible(true);
            
            if (method.getName().startsWith("getSystemCpuLoad") && Modifier.isPublic(method.getModifiers())) {
                try {
                    value = (double) method.invoke(operatingSystemMXBean);
                } catch (Exception e) {
                    value = 0;
                }
                return value;
            }
        }
        return value;
    }
    
    public long getMEMUsage() { //docs.oracle.com/javase/7/docs/jre/api/management/extension/com/sun/management/OperatingSystemMXBean.html
        OperatingSystemMXBean operatingSystemMXBean = ManagementFactory.getOperatingSystemMXBean();
        long value = 0;
        
        for(Method method : operatingSystemMXBean.getClass().getDeclaredMethods()) {
            method.setAccessible(true);
            
            if (method.getName().startsWith("getFreePhysicalMemorySize") && Modifier.isPublic(method.getModifiers())) {
                try {
                    value = (long) method.invoke(operatingSystemMXBean);
                } catch (Exception e) {
                    value = 0;
                }
                return value;
            }
        }
        return value;
    }
    
    public boolean isRunning(){
        if(timeline != null){
            if(timeline.getStatus() == Animation.Status.RUNNING){
                return true;
            }
        }
        return false;
    }
    
    private void update(){
        double rotation = 195 + (300*cpu);
        handImage.setRotate(rotation);
    }
    
    
    public void start() {
        timeline.play();
    }
    
    public void stop() {
        timeline.stop();
    }
    
    public void cpuLoadChart() {
        series.getData().add(new XYChart.Data(cpuData, (cpu*100)));
        cpuData++;
    }
    
    public void updateMemSize() {
        memLabel.setText("Free Physical Memory Size: " + mem/1000000 + " MB"); //Megabyte conversion is that huge number
    }
    
    public void recordCPUChart() {
        recordData++;
        recordSeries.getData().add(new XYChart.Data(recordData, (cpu*100)));
    }
    
    public void updateDigital(){
        DecimalFormat df = new DecimalFormat("#.##");
        cpuLabel.setText(df.format(cpu*100) + "%");
    }
    
    public void reset(){
        count = 0;
        cpuData = 0;
        recordData = 0;
        firstRun = true;
        handImage.setRotate(195);
        startBtn.setStyle("-fx-background-color:#7CFC00");
        startBtn.setText("Start");
        resetBtn.setText("Record");
        cpuLabel.setText("0.00%");
        recordingTime.setText("Recording at Time --:--:--");
        memLabel.setText("Free Physical Memory Size: 0 MB");
        
        cpuLoad.getData().clear();
        series.getData().clear();
        cpuLoad.getData().add(series);
        
        recordedUsage.getData().clear();
        recordSeries.getData().clear();
        recordedUsage.getData().add(recordSeries);
    }
    
    public void recordTitle(){
        count++;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mm:ss a");
        LocalDateTime dateTime = LocalDateTime.now(); //Start & end of stackabuse.com/how-to-get-current-date-and-time-in-java/
        String currentTime = dateTime.format(formatter);
        recordingTime.setText("Recording " + count + " at Time " + currentTime);
    }
}
