/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gjr7dztimerstopwatchf20;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.util.Duration;

/**
 *
 * @author gregryterski
 */
public class TimerStopWatch {
    private double secondsElapsed = 0.0; //USE DATA Encapsulation for the challenge
    private double tickTimeInSeconds = 1.0; //MUST use getters & setters to modify these values
    private double angleDeltaPerSeconds = 6.0; 
    private double record1Time = 0.0;
    private double record2Time = 0.0;
    private double record3Time = 0.0;
    private double startTime = 0;
    private boolean firstRun = true;
    private boolean secondRun = false;
    
    private final DateFormat timePFormat = new SimpleDateFormat("mm:ss");
    private final DateFormat timeFormat = new SimpleDateFormat("mm:ss"); //stackoverflow.com/questions/38566638/javafx-displaying-time-and-refresh-in-every-second
    private final DateFormat timerFormat = new SimpleDateFormat("ss");
    private final DateFormat timerSFormat = new SimpleDateFormat("s");
    private final DateFormat timeSSFormat = new SimpleDateFormat("SS");
    
    int runTenth = 0;
    int runDigit = 0;
    
    Label timerLabel;
    Label timePassed;
    
    Label record1;
    Label record2;
    Label record3;
    
    private Timeline timeline;
    private KeyFrame keyFrame;
    
    private VBox records;
    private VBox vboxTimer;
    private HBox controlButtons;
    
    private Button stopStart;
    private Button resetRecord;

     
    
    private StackPane analog;
    private GridPane rootContainer;
    private ImageView dialImageView;
    private ImageView handImageView;
    private Image dialImage;
    private Image handImage;
    private String dialImageName = "clockface.png";
    private String handImageName = "hand.png";
    
    public TimerStopWatch(double initalTime){
        rootContainer = new GridPane();
        startTime = initalTime;
        secondsElapsed = 0;
        tickTimeInSeconds = 0.1;
        angleDeltaPerSeconds = 6.0;
        dialImageName = "clockface.png";
        handImageName = "hand.png";
        setUpButtons();
        setupTimer();
        setupUI();
        
        
    }
    
    public void setupUI(){
        analog = new StackPane();
        
        dialImageView = new ImageView();
        handImageView = new ImageView();
        
        dialImage = new Image(getClass().getResourceAsStream(dialImageName));
        handImage = new Image(getClass().getResourceAsStream(handImageName));
       
        dialImageView.setImage(dialImage);
        handImageView.setImage(handImage);
        
        records = new VBox();
        record1 = new Label("Rec 00 00:00.00");
        record1.setFont(Font.font ("Verdana", 15));
        
        record2 = new Label("Rec 00 00:00.00");
        record2.setFont(Font.font ("Verdana", 15));
        
        record3 = new Label("Rec 00 00:00.00");
        record3.setFont(Font.font ("Verdana", 15));
        
        records.getChildren().addAll(record1, record2, record3);
        records.setAlignment(Pos.CENTER_RIGHT);
        
        vboxTimer = new VBox();
        timerLabel = new Label();
        timerLabel.setText("Timer " + startTime);
        timerLabel.setFont(Font.font ("Verdana", 15));
        
        timePassed = new Label();
        timePassed.setText("00:00.00");
        timePassed.setFont(Font.font ("Verdana", 20));
        
        vboxTimer.setSpacing(8);
        vboxTimer.getChildren().addAll(timePassed, timerLabel);
        vboxTimer.setAlignment(Pos.CENTER_LEFT);
        rootContainer.add(vboxTimer, 0, 1);
        
        analog.getChildren().addAll(dialImageView, handImageView);
        rootContainer.add(analog, 0, 0);
        rootContainer.add(records, 0, 1);
        rootContainer.setAlignment(Pos.CENTER);
        
        timeline = new Timeline(keyFrame);
        timeline.setCycleCount(Animation.INDEFINITE);
        
        if(!isRunning()){
            timeline.play();
        }
    }
    
    public void setupTimer(){
        if(isRunning()){
            timeline.stop();
        }
        
        keyFrame = new KeyFrame(Duration.millis(tickTimeInSeconds * 1000), (ActionEvent event) -> {
            tickTimeInSeconds = 0.1;
            
            double updatedTime = (startTime - secondsElapsed)*1000;
            
            int centisec = Integer.parseInt(timeSSFormat.format(updatedTime));
            centisec = centisec/10;
            timePassed.setText(timePFormat.format(secondsElapsed*1000) + ":" + timeSSFormat.format(centisec));
            if(startTime>=10){
                timerLabel.setText("Timer " + timerFormat.format(updatedTime) + "." + timeSSFormat.format(centisec));
            } else{
                timerLabel.setText("Timer " + timerSFormat.format(updatedTime) + "." + timeSSFormat.format(centisec));
            }
            
            if(updatedTime <= 0.00){
                timerLabel.setText("Time Up!");
                resetRecord.setText("Reset");
                stop();
                Alert timeUp = new Alert(Alert.AlertType.INFORMATION);
                timeUp.setTitle("Time is up!!");
                timeUp.setHeaderText("Message");
                timeUp.setContentText("Time is up... No more records...");
                timeUp.show();
            }
            update();
        });
        
    }
       
    private void setUpButtons(){
        controlButtons = new HBox();
        stopStart = new Button("Start");
        resetRecord = new Button("Record");
        stopStart.setMaxWidth(Double.MAX_VALUE);
        resetRecord.setMaxWidth(Double.MAX_VALUE);
        
        GridPane.setValignment(controlButtons, VPos.BOTTOM);
        
        stopStart.setOnAction((ActionEvent event) -> {
            if(isRunning()){
                stop();
                stopStart.setText("Start");
                resetRecord.setText("Reset");
            }
            else {
                stopStart.setText("Stop");
                resetRecord.setText("Record");
                start();
            }
        });
        
        resetRecord.setOnAction((ActionEvent event) -> {
            if(isRunning()){
                record();
            }
            else {
                resetRecord.setText("Reset");
                reset();
            }
        });
        
        controlButtons.getChildren().addAll(resetRecord, stopStart);
        
        controlButtons.setSpacing(10);
        controlButtons.setAlignment(Pos.BOTTOM_CENTER);
        controlButtons.setPadding(new Insets(25, 25, 25, 25));
        
        rootContainer.add(controlButtons, 0, 3);
    }
    
    private void update(){
        secondsElapsed += tickTimeInSeconds;
        double rotation = secondsElapsed * angleDeltaPerSeconds;
        handImageView.setRotate(rotation);
    }
    
    public boolean isRunning(){
        if(timeline != null){
            if(timeline.getStatus() == Animation.Status.RUNNING){
                return true;
            }
        }
        return false;
    }
    
    public Parent getRootContainer(){
        return rootContainer;
    }
    
    public Double getWidth(){
        if(dialImage != null) return dialImage.getWidth();
        else return 0.0;
    }
    
    public Double getHeight(){
        if(dialImage != null) return dialImage.getHeight();
        else return 0.0;
    }
    
    public void start(){
        timeline.play(); 
    }
    
    public void stop(){
        timeline.stop();
    }
    
    public void reset(){
        handImageView.setRotate(0);
        runDigit = 0;
        runTenth = 0;
        firstRun = true;
        secondRun = false;
        record1Time = 0;
        record2Time = 0;
        record3Time = 0;
        secondsElapsed = 0;
        
        stopStart.setText("Start");
        resetRecord.setText("Record");
        
        timerLabel.setText("Timer " + startTime);
        timePassed.setText("00:00.00");
        
        record1.setText("Rec " + runTenth + runDigit + " " + timeFormat.format(record1Time) + ".00");
        record2.setText("Rec " + runTenth + runDigit + " " + timeFormat.format(record2Time) + ".00");
        record3.setText("Rec " + runTenth + runDigit + " " + timeFormat.format(record3Time) + ".00");
    }
    
    public double displayTime(){
        return secondsElapsed;
    }
    
    public void record(){ //UPDATE Records
        double disTime = displayTime();
        double difTime = 0;
        int centisec = 0;
        runDigit++;
        if(runDigit >= 10){
            runTenth++;
            runDigit = 0;
        }
        
        if(firstRun == true){
            record1Time = disTime;
            difTime = (disTime - record3Time)*1000;
            centisec = Integer.parseInt(timeSSFormat.format(difTime));
            centisec = centisec/10;
            
            record1.setText("Rec " + runTenth + runDigit + " " + timeFormat.format(difTime) 
                            + "." + timeSSFormat.format(centisec));
            
            firstRun = false;
            secondRun = true;
        } else if (secondRun == true){
            record2Time = disTime;
            difTime = (disTime - record1Time)*1000;
            centisec = Integer.parseInt(timeSSFormat.format(difTime));
            centisec = centisec/10;
            record2.setText("Rec " + runTenth + runDigit + " " + timeFormat.format(difTime)
                            + "." + timeSSFormat.format(centisec));
            secondRun = false;
        } else{
            record3Time = disTime;
            difTime = (disTime - record2Time)*1000;
            centisec = Integer.parseInt(timeSSFormat.format(difTime));
            centisec = centisec/10;
            record3.setText("Rec " + runTenth + runDigit + " " + timeFormat.format(difTime) 
                            + "." + timeSSFormat.format(centisec));
            firstRun = true;
        }
    }
    
    public void setTickTimeInSeconds(Double tickTimeInSeconds){
        this.tickTimeInSeconds = tickTimeInSeconds;
        setupTimer();
    }
}

