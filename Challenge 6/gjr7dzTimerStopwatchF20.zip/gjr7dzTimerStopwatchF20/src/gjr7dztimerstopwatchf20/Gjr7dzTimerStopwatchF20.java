/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gjr7dztimerstopwatchf20;

import java.util.Optional;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;


/**
 *
 * @author gregryterski
 */
public class Gjr7dzTimerStopwatchF20 extends Application {
    public String title = "New Stop Watch";
    
    @Override
    public void start(Stage primaryStage) {
        
        TextInputDialog timePrompt = new TextInputDialog();
        timePrompt.setTitle("Timer Start Time Set Up");
        timePrompt.setHeaderText("Set up the start time:");
        timePrompt.setContentText("Please set up the start time (Integer):");
        Optional<String> result = timePrompt.showAndWait();
        if(!result.isPresent()){
            return;
        } else{
            
        boolean isDouble = false;
        try{
            Double.parseDouble(result.get());
            isDouble = true;
        } catch(NumberFormatException e){
            isDouble = false;
        }
        
        if(isDouble){
         
        double startTime = Double.parseDouble(result.get());
        TimerStopWatch stopWatch = new TimerStopWatch(startTime);
        
        Scene scene = new Scene(stopWatch.getRootContainer(), 
                                stopWatch.getWidth()+80, 
                                stopWatch.getHeight()+180);
        
        primaryStage.setTitle(title);
        primaryStage.setScene(scene);
        primaryStage.show();
        
        stopWatch.setTickTimeInSeconds(0.01);
        stopWatch.start();
        stopWatch.setTickTimeInSeconds(1.0);
        }
        else {
            Alert nonNumber = new Alert(Alert.AlertType.ERROR, "Insert only numbers!");
            nonNumber.show();
            return;
        }
        }
        
    }

    
    public static void main(String[] args) {
        launch(args);
    }    
}
