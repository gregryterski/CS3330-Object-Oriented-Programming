/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gjr7dzmvctimerstopwatchfxmlf20;

/**
 *
 * @author gregryterski
 */
public class Model extends AbstractModel {
    
    private final double angleDeltaPerSeconds = 6.0;
    private double angle = 0.0;
    
    public Model(){
        
    }
     
    @Override
    public void update(){
        super.update();
        double rotation = secondsElapsed * angleDeltaPerSeconds;
        updateAnalog(rotation);
    }
    
    @Override
    public void reset(){
        super.reset();
        angle = 0.0;
    }
    
    public void updateAnalog(double rotate){
        double oldAngle = angle;
        angle = rotate;
        firePropertyChange("Analog", oldAngle, angle);
    }   
   
}