/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gjr7dzmvctimerstopwatchfxmlf20;

import javafx.scene.control.Alert;

/**
 *
 * @author gregryterski
 */
public class DigitalModel extends AbstractModel {
    
    private boolean switchTime = true;
    private double record1Time = 0.0;
    private double record2Time = 0.0;
    private boolean timeUpT = false;
    
    private double newTime = 0.0;
    private double timerVal = 0.0;
    private double lapVal = 0.0;
    
    public DigitalModel(){
        timerVal = startTime;
    }
    
    @Override
    public void update(){
        super.update();
        if((startTime-secondsElapsed)*1000 <= 0.00 && timeUpT == false){
                Alert timeUp = new Alert(Alert.AlertType.INFORMATION);
                timeUp.setTitle("Time is up!!");
                timeUp.setHeaderText("Message");
                timeUp.setContentText("Time is up... No more records...");
                timeUp.show();
                first = true;
                timeUpT = true;
            }
        double thisIsTheTime = secondsElapsed;
        updateTDigital(thisIsTheTime);
        updateElapsedDigital(thisIsTheTime);
    }
    
    @Override
    public void reset(){
        super.reset();
        switchTime = true;
        record1Time = 0.0;
        record2Time = 0.0;
        newTime = 0.0;
        timerVal = 0.0;
        lapVal = 0.0;
    }
    
    public void updateTDigital(double timeElapsed){
        double oldTimerVal = timerVal;
        timerVal = (startTime-timeElapsed)*1000;
        firePropertyChange("Timer", oldTimerVal, timerVal);
    }
    
    public void updateLapDigital(){
        double oldVal = lapVal;
        lapVal = lapTime()*1000;
        firePropertyChange("Lap", oldVal, lapVal);
    }
    
    public void updateElapsedDigital(double timeElapsed){
        double oldTime = newTime;
        newTime = timeElapsed*1000;
        firePropertyChange("Elapsed", oldTime, newTime);
    }
    
    public double lapTime(){
        double difTime;
        if(switchTime){
            record1Time = secondsElapsed;
            difTime = (secondsElapsed - record2Time);
            switchTime = false;
        } else{
            record2Time = secondsElapsed;
            difTime = (secondsElapsed - record1Time);
            switchTime = true;
        }
        return difTime;
    }
}
