/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gjr7dzmvctimerstopwatchfxmlf20;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Optional;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;
import javafx.util.Duration;

/**
 *
 * @author gregryterski
 * 
 * @reference https://www.oracle.com/technical-resources/articles/javase/mvc.html
 * 
 * All this code came from the corresponding link
 */
public abstract class AbstractModel {

    protected PropertyChangeSupport propertyChangeSupport;
    
    protected double secondsElapsed = 0.0; //USE DATA Encapsulation for the challenge
    protected double tickTimeInSeconds; //MUST use getters & setters to modify these values
    protected double startTime = 0.0;
    protected boolean first = true;
    
    protected Timeline timeline;
    protected KeyFrame keyFrame;

    public AbstractModel() {
        propertyChangeSupport = new PropertyChangeSupport(this);
        
        tickTimeInSeconds = 0.1;
        setUpTimer();
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
        propertyChangeSupport.firePropertyChange(propertyName, oldValue, newValue);
    }

    public void setUpTimer(){
        keyFrame = new KeyFrame(Duration.millis(tickTimeInSeconds * 1000), (ActionEvent event) -> {
            update();
        });
        timeline = new Timeline(keyFrame);
        timeline.setCycleCount(Animation.INDEFINITE);
    }
    
    public void update(){
        if(first == false){
            secondsElapsed += tickTimeInSeconds;
        }
        first = false;
    }
    
    public boolean isRunning(){
        if(timeline != null){
            if(timeline.getStatus() == Animation.Status.RUNNING){
                return true;
            }
        }
        return false;
    }
    
    public void start(){
        timeline.play(); 
    }
    
    public void stop(){
        timeline.stop();
    }
    
    public void setStartTime(double sentTime){
        startTime = sentTime;
    }
    
    public void reset(){
        secondsElapsed = 0.0;
        first = true;
    }
}
