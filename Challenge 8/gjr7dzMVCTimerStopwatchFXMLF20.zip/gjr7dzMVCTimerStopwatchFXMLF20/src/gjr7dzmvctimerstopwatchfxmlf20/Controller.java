/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gjr7dzmvctimerstopwatchfxmlf20;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

/**
 *
 * @author gregryterski
 */
public class Controller implements Initializable, PropertyChangeListener {
    
    private boolean isDouble = false;
    private boolean resetClicked = false;
    private int count = 0;
    private final DateFormat timeFormat = new SimpleDateFormat("mm:ss");
    private final DateFormat timeSSFormat = new SimpleDateFormat("SS");
    private final DateFormat timerSFormat = new SimpleDateFormat("s");
    private final DateFormat timerFormat = new SimpleDateFormat("ss");
    private XYChart.Series series;
    
    Model model;
    DigitalModel digital;
    
    private Label label;
    @FXML
    private ImageView guageImage;
    @FXML
    private ImageView handImage;
    @FXML
    private Label elapsedTime;
    @FXML
    private Label lapLabel;
    @FXML
    private Label timerLabel;
    @FXML
    private LineChart<?, ?> recordChart;
    @FXML
    private HBox controlButtons;
    @FXML
    private Button startStopButton;
    @FXML
    private Button recordResetButton;
    @FXML
    private NumberAxis yAxis;
    @FXML
    private NumberAxis xAxis;
    @FXML
    private ImageView lightning1;
    @FXML
    private ImageView lightning2;
    @FXML
    private ImageView fireGif;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lightning1.toBack();
        lightning2.toBack();
        fireGif.toBack();
        digital = new DigitalModel();
        model = new Model();
        TextInputDialog timePrompt = new TextInputDialog();
        timePrompt.setTitle("Timer Start Time Set Up");
        timePrompt.setHeaderText("Set up the start time:");
        timePrompt.setContentText("Please set up the start time (Integer):");
        
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("You have inserted an incorrect value, please"
                             + " insert a positive number as an integer.");
        alert.setTitle("Incorrect Vlaue!!!");
        
        do{
            Optional<String> result = timePrompt.showAndWait();
            if(!result.isPresent()){
                System.exit(0);
            } else{
                try{
                    Double.parseDouble(result.get());
                    isDouble = true;
                } catch(NumberFormatException e){
                    isDouble = false;
                }
            
                if(isDouble && Double.parseDouble(result.get()) > 0){
                    double startTime;
                    startTime = Double.parseDouble(result.get());
                    digital.setStartTime(startTime);
                    model.setStartTime(startTime);
                } else {
                    isDouble = false;
                    alert.showAndWait();
                }
            }
        }while(isDouble == false);
        
        digital.addPropertyChangeListener(this);
        model.addPropertyChangeListener(this); //This is needed once fireproperty change is used
        
        series = new XYChart.Series();
        recordChart.getData().add(series);
    }
    
    @Override
    public void propertyChange(PropertyChangeEvent evt){
        if(evt.getPropertyName().equals("Analog")){
            handImage.setRotate((double)evt.getNewValue());
        } else if(evt.getPropertyName().equals("Timer")){
            double holder = (double)evt.getNewValue();
            int milisec = Integer.parseInt(timeSSFormat.format(holder))/10;
            
            if(holder>=10000){
                timerLabel.setText("Timer " + timerFormat.format(holder) + "." + timeSSFormat.format(milisec));
            } else if(holder <= 0.00){
                timerLabel.setText("Time is Up!");
            } else {
                timerLabel.setText("Timer " + timerSFormat.format(holder) + "." + timeSSFormat.format(milisec));
            }
        } else if(evt.getPropertyName().equals("Lap")){
            count++;
            double holder = (double)evt.getNewValue();
            int milisec = Integer.parseInt(timeSSFormat.format(holder))/10;
            
            lapLabel.setText("Lap " + count + " " + timeFormat.format(holder) 
                            + "." + timeSSFormat.format(milisec));
            series.getData().add(new XYChart.Data(count, holder/1000));
        } else if(evt.getPropertyName().equals("Elapsed")){
            double holder = (double)evt.getNewValue();
            int milisec = Integer.parseInt(timeSSFormat.format(holder))/10;
            
            elapsedTime.setText(timeFormat.format(evt.getNewValue()) + "." 
                                + timeSSFormat.format(milisec));
        }
    }

    @FXML
    private void startStopButton(ActionEvent event) {
        if(model.isRunning() && digital.isRunning()) {
            model.stop();
            digital.stop();
            startStopButton.setText("Start");
            startStopButton.setStyle("-fx-background-color:#7CFC00");
            recordResetButton.setText("Reset");
            resetClicked = true; //Makes reset available
        } else {
            model.start();
            digital.start();
            startStopButton.setText("Stop");
            startStopButton.setStyle("-fx-background-color:FF0000");
            recordResetButton.setText("Record");
        }
    }

    @FXML
    private void recordResetButton(ActionEvent event) {
        if(model.isRunning() && digital.isRunning()){
            if(timerLabel.getText() != "Time is Up!"){
                digital.updateLapDigital();
            } else{
                Alert timeUp = new Alert(Alert.AlertType.INFORMATION);
                timeUp.setTitle("Time is up!!");
                timeUp.setHeaderText("Message");
                timeUp.setContentText("Time is up... No more records...");
                timeUp.show();
            }
        } else {
            if(resetClicked){ //Prevents the user from spamming reset & causing it to mess up the graph
            elapsedTime.setText("--:--:--.--");
            lapLabel.setText("Lap -: --:--:--.--");
            timerLabel.setText("Timer --:--");
            series.getData().clear();
            recordChart.getData().clear();
            recordChart.getData().add(series);
            count = 0;
            handImage.setRotate(0);
            model.reset();
            digital.reset();
            resetClicked = false;
            }
        }
    }
}